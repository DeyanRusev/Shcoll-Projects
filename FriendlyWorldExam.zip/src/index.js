const express = require('express');
const handlebars = require('express-handlebars');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');

const { auth } = require('./middlewares/authMiddleware');
const { errorHandler } = require('./middlewares/errorHandler');


const routes = require('./routes');

const app = express();
const PORT = 3000;

mongoose.connect('mongodb://127.0.0.1:27017/animals')
    .then(() => console.log('DB connected succssfully'))
    .catch(err => console.log('DB Error', err.message));

app.engine('hbs', handlebars.engine({
    extname: 'hbs'
}));

app.set('view engine', 'hbs');
app.set('views', 'src/views');

app.use(express.static('src/public'));
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(auth);
app.use(routes);
app.use(errorHandler);

app.listen(PORT, console.log(`Server is listening on port ${PORT}...`));


