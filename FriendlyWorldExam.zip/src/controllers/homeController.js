const router = require('express').Router();
const animalManager = require('../menagers/animalManager');


router.get('/', async (req, res) => {

    const animals = await animalManager.getAllLast().lean();

    res.render('home', {animals});
})

router.get('/404', (req, res) => {
    res.render('404');
})

router.get('/search', async (req, res) => {


    res.render('search');
});

router.post('/search', async (req, res) => {
    
    const {search} = req.body;

    let animals = await animalManager.search(search).lean()
    
    res.render('search', {animals});

});

module.exports = router;
