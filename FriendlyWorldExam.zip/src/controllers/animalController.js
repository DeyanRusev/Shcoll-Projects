const router = require('express').Router();
const animalManager = require('../menagers/animalManager');
const { getErrorMessage } = require('../utils/errorHelper');
const { isAuth } = require('../middlewares/authMiddleware');

router.get('/', async (req, res) => {

    const animals = await animalManager.getAll().lean();

    res.render('animals', { animals });
})

router.get('/create', isAuth, (req, res) => {

    res.render('animals/create');
})

router.post('/create', isAuth, async (req, res) => {

    const animalData = {
        ...req.body,
        owner: req.user._id
    }

    try {

        await animalManager.create(animalData);

        res.redirect('/animals')


    } catch (err) {
        res.render('animals/create', { error: getErrorMessage(err), ...animalData })
    }
})

router.get('/:animalId/details', async (req, res) => {

    const animalId = req.params.animalId;
    const animal = await animalManager.getOne(animalId).lean();

    const isOwner = req.user?._id == animal.owner._id;
    const hasDonate = animal.donations.includes(req.user?._id);

    res.render('animals/details', { animal, isOwner, hasDonate });
})

router.get('/:animalId/donate', isAuth, async (req, res) => {

    const userId = req.user._id;
    const animalId = req.params.animalId;

    await animalManager.donate(animalId, userId);

    res.redirect(`/animals/${animalId}/details`);
})

router.get('/:animalId/delete', isAuth, async (req, res) => {

    const animalId = req.params.animalId;

    try {
        await animalManager.deleteOne(animalId);

        res.redirect('/animals')

    } catch (err) {

        res.render(`/${animalId}/details`, { error: getErrorMessage(err) })
    }


})

router.get('/:animalId/edit', isAuth, async (req, res) => {

    const animalId = req.params.animalId;

    const animal = await animalManager.getOne(animalId).lean();

    res.render('animals/edit', { animal })

})

router.post('/:animalId/edit', isAuth, async (req, res) => {

    const animalId = req.params.animalId;
    const animal = req.body;

    try {

        await animalManager.editOne(animalId, animal);
        res.redirect(`/animals/${animalId}/details`);

    } catch (err) {
        res.render('animals/edit', { error: getErrorMessage(err), animal })
    }

})

module.exports = router;