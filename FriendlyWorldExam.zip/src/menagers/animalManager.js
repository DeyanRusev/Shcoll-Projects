const Animal = require('../models/Animal');

exports.getAll = () => Animal.find();

exports.getAllLast = () => Animal.find().sort({'date': -1}).limit(3);

exports.create = (animalData) => Animal.create(animalData);

exports.getOne = (animalId) => Animal.findById(animalId);

exports.donate = async (animalId, user) => {

    const animal = await Animal.findById(animalId);

    animal.donations.push(user);

    return animal.save();

}

exports.deleteOne = (animalId) => Animal.findByIdAndDelete(animalId);

exports.editOne = (animalId, animal) => Animal.findByIdAndUpdate(animalId, animal, {runValidators: true});

exports.search = (search) => Animal.find({location: {$regex: new RegExp(search, 'i')}})